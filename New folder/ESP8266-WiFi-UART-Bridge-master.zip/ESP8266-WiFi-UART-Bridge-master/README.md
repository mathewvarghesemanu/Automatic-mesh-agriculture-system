# ESP8266-WiFi-UART-Bridge
Transparent WiFi (TCP, UDP) to UART Bridge, supports both AP and STATION WiFi modes.
The .ino file is the code for the ESP. Use Arduino IDE for ESP8266 to compile and upload it to the ESP8266.

I made this project in order to use with my RoboRemo app, but it is not limited to that.
You can use it wherever you want, but on your own risk. Read license file for more details.
